import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Mic2, ArrowRight, Users, FileText, MessageSquare, Lightbulb,
  Smile, BarChart2, Shield, TrendingUp, Star, Target, Eye,
  BookOpen, Heart, Cpu, AlertTriangle, Award, Zap, RefreshCw,
  CheckCircle, Globe, ChevronRight
} from 'lucide-react';
import { useStats } from '../hooks/useStats';
import { formatNumber } from '../lib/utils';
import AuthModal from '../components/AuthModal';
import { useAuth } from '../contexts/AuthContext';

function AnimatedNumber({ value, duration = 1500 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    if (value === 0) return;
    const start = Date.now();
    const step = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.floor(eased * value));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [value, duration]);
  return <span>{formatNumber(display)}</span>;
}

const categories = [
  { icon: BookOpen, name: 'Exam Pressure', color: '#ef4444', desc: 'Stress & coping' },
  { icon: Heart, name: 'Mental Health', color: '#10b981', desc: 'Wellness talks' },
  { icon: Cpu, name: 'AI in Education', color: '#3b82f6', desc: 'Future of learning' },
  { icon: AlertTriangle, name: 'School Problems', color: '#f59e0b', desc: 'Systemic issues' },
  { icon: Shield, name: 'Student Rights', color: '#8b5cf6', desc: 'Advocacy' },
  { icon: Lightbulb, name: 'Study Tips', color: '#06b6d4', desc: 'Smarter learning' },
  { icon: Award, name: 'Scholarships', color: '#eab308', desc: 'Opportunities' },
  { icon: TrendingUp, name: 'Career Advice', color: '#f97316', desc: 'Future paths' },
  { icon: Smile, name: 'Memes', color: '#ec4899', desc: 'Student life humor' },
  { icon: Zap, name: 'Innovations', color: '#14b8a6', desc: 'Student inventions' },
  { icon: RefreshCw, name: 'Education Reform', color: '#6366f1', desc: 'Systemic change' },
];

export default function Landing() {
  const { stats, loading } = useStats();
  const { user } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');

  const openSignup = () => { setAuthMode('signup'); setShowAuth(true); };

  const statCards = [
    { icon: Users, label: 'Registered Members', value: stats.totalMembers, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { icon: FileText, label: 'Total Posts', value: stats.totalPosts, color: 'text-green-400', bg: 'bg-green-400/10' },
    { icon: MessageSquare, label: 'Comments', value: stats.totalComments, color: 'text-teal-400', bg: 'bg-teal-400/10' },
    { icon: Lightbulb, label: 'Innovation Ideas', value: stats.totalInnovations, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
    { icon: Smile, label: 'Memes Shared', value: stats.totalMemes, color: 'text-pink-400', bg: 'bg-pink-400/10' },
    { icon: BarChart2, label: 'Polls Created', value: stats.totalPolls, color: 'text-orange-400', bg: 'bg-orange-400/10' },
    { icon: Eye, label: 'Weekly Active', value: stats.recentlyActive, color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
    { icon: CheckCircle, label: 'Reports Resolved', value: stats.reportsResolved, color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
        {/* Background layers */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1181534/pexels-photo-1181534.jpeg"
            alt="Students collaborating"
            className="w-full h-full object-cover opacity-10"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 via-gray-950/60 to-gray-950" />
        </div>

        {/* Glow effects */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/4 w-[300px] h-[300px] bg-cyan-600/8 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-5xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 mb-8">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-sm text-blue-300 font-medium">
              {loading ? 'Loading...' : `${formatNumber(stats.totalMembers)} students already joined`}
            </span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black leading-tight mb-6 tracking-tight">
            Students deserve a
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400">
              real voice.
            </span>
          </h1>

          <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-10 leading-relaxed">
            A student-led movement to rethink and improve the education system.
            <span className="text-gray-400"> Speak freely. Be heard. Create change.</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <Link
                to="/feed"
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold px-8 py-4 rounded-xl text-lg transition-all hover:shadow-lg hover:shadow-blue-500/20"
              >
                Go to Feed <ArrowRight size={20} />
              </Link>
            ) : (
              <>
                <button
                  onClick={openSignup}
                  className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold px-8 py-4 rounded-xl text-lg transition-all hover:shadow-lg hover:shadow-blue-500/20"
                >
                  Join the Movement <ArrowRight size={20} />
                </button>
                <Link
                  to="/feed"
                  className="inline-flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-semibold px-8 py-4 rounded-xl text-lg transition-all"
                >
                  Explore Feed
                </Link>
              </>
            )}
          </div>

          {/* Hero images row */}
          <div className="mt-16 grid grid-cols-3 gap-3 max-w-3xl mx-auto opacity-60">
            {[
              'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg',
              'https://images.pexels.com/photos/3184299/pexels-photo-3184299.jpeg',
              'https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg',
            ].map((src, i) => (
              <div key={i} className="aspect-video rounded-xl overflow-hidden border border-white/10">
                <img src={src} alt="Students" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Real Stats */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-4 py-2 mb-6">
              <CheckCircle size={14} className="text-green-400" />
              <span className="text-sm text-green-300 font-medium">Community Transparency — All numbers are real</span>
            </div>
            <h2 className="text-4xl font-bold text-white mb-4">Real Numbers. Real People.</h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto">
              We never inflate stats. Every number here comes directly from our database in real time.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {statCards.map(({ icon: Icon, label, value, color, bg }) => (
              <div key={label} className="bg-gray-900/50 border border-white/5 rounded-2xl p-6 text-center hover:border-white/10 transition-all">
                <div className={`inline-flex items-center justify-center w-10 h-10 ${bg} rounded-xl mb-4`}>
                  <Icon size={20} className={color} />
                </div>
                <div className={`text-3xl font-black mb-1 ${color}`}>
                  {loading ? '—' : <AnimatedNumber value={value} />}
                </div>
                <div className="text-xs text-gray-500 font-medium">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-24 px-4 bg-gray-900/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">What Students Are Talking About</h2>
            <p className="text-gray-400 text-lg">Explore real discussions across every aspect of student life</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {categories.map(({ icon: Icon, name, color, desc }) => (
              <Link
                key={name}
                to={`/feed?category=${name.toLowerCase().replace(/ /g, '-')}`}
                className="group bg-gray-900/50 border border-white/5 rounded-xl p-4 hover:border-white/15 transition-all hover:-translate-y-0.5"
              >
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: color + '20' }}>
                    <Icon size={18} style={{ color }} />
                  </div>
                  <div>
                    <div className="text-white text-sm font-semibold leading-tight">{name}</div>
                    <div className="text-gray-500 text-xs mt-0.5">{desc}</div>
                  </div>
                </div>
                <ChevronRight size={14} className="text-gray-600 group-hover:text-gray-400 mt-3 transition-colors" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Built for Students, by Students</h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto">Every feature designed to amplify authentic student voices</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Eye,
                title: 'Anonymous Posting',
                desc: 'Share sensitive concerns without fear. Your identity stays protected when you choose to post anonymously.',
                color: 'text-blue-400',
                bg: 'bg-blue-400/10',
              },
              {
                icon: Lightbulb,
                title: 'Innovation Hub',
                desc: 'Showcase your ideas, inventions, and solutions to fix the broken education system.',
                color: 'text-yellow-400',
                bg: 'bg-yellow-400/10',
              },
              {
                icon: Shield,
                title: 'Safe & Moderated',
                desc: 'Anti-bullying systems, spam protection, and community guidelines keep this space respectful.',
                color: 'text-green-400',
                bg: 'bg-green-400/10',
              },
              {
                icon: BarChart2,
                title: 'Real Polls',
                desc: 'Create polls on education topics. See what students across the community actually think.',
                color: 'text-orange-400',
                bg: 'bg-orange-400/10',
              },
              {
                icon: Globe,
                title: 'Open Discussions',
                desc: 'Debate education policies, share study strategies, advocate for student rights.',
                color: 'text-cyan-400',
                bg: 'bg-cyan-400/10',
              },
              {
                icon: Star,
                title: 'Reputation System',
                desc: 'Earn badges and reputation points for quality contributions to the community.',
                color: 'text-pink-400',
                bg: 'bg-pink-400/10',
              },
            ].map(({ icon: Icon, title, desc, color, bg }) => (
              <div key={title} className="bg-gray-900/50 border border-white/5 rounded-2xl p-6 hover:border-white/10 transition-all">
                <div className={`inline-flex items-center justify-center w-12 h-12 ${bg} rounded-xl mb-5`}>
                  <Icon size={22} className={color} />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="py-24 px-4 bg-gray-900/30">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 mb-6">
              <Mic2 size={14} className="text-blue-400" />
              <span className="text-sm text-blue-300 font-medium">Founded by Kamei</span>
            </div>
            <h2 className="text-4xl font-bold text-white mb-4">The Vision Behind StudentVoice</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Eye,
                title: 'Vision',
                color: 'text-blue-400',
                bg: 'bg-blue-400/10',
                text: 'A world where every student — regardless of background, institution, or geography — has a genuine platform to shape the future of education.',
              },
              {
                icon: Target,
                title: 'Mission',
                color: 'text-teal-400',
                bg: 'bg-teal-400/10',
                text: 'To build an authentic, transparent, student-powered community that transforms frustration into systemic change through collective voice and innovation.',
              },
              {
                icon: TrendingUp,
                title: 'Goals',
                color: 'text-green-400',
                bg: 'bg-green-400/10',
                text: 'Bridge the gap between students and policymakers. Surface real problems. Amplify proven solutions. Track real progress toward a better education system.',
              },
            ].map(({ icon: Icon, title, color, bg, text }) => (
              <div key={title} className="bg-gray-900/50 border border-white/5 rounded-2xl p-6">
                <div className={`inline-flex items-center justify-center w-12 h-12 ${bg} rounded-xl mb-5`}>
                  <Icon size={22} className={color} />
                </div>
                <h3 className={`text-lg font-bold mb-3 ${color}`}>{title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 bg-gradient-to-r from-blue-500/10 via-cyan-500/10 to-teal-500/10 border border-blue-500/20 rounded-2xl p-8 text-center">
            <blockquote className="text-xl text-gray-200 font-medium italic leading-relaxed mb-4">
              "I built StudentVoice because I believe students are the most powerful force for educational change.
              We just needed a real place to speak."
            </blockquote>
            <cite className="text-blue-400 font-semibold not-italic">— Kamei, Founder of StudentVoice</cite>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-5xl font-black text-white mb-6">
            Your voice matters.
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-teal-400">
              Use it.
            </span>
          </h2>
          <p className="text-gray-400 text-lg mb-10">
            Join {loading ? 'students' : `${formatNumber(stats.totalMembers)} students`} already shaping the future of education.
          </p>
          {!user && (
            <button
              onClick={openSignup}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold px-10 py-4 rounded-xl text-lg transition-all hover:shadow-lg hover:shadow-blue-500/20"
            >
              Join StudentVoice — It's Free <ArrowRight size={20} />
            </button>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-500 rounded-lg flex items-center justify-center">
              <Mic2 size={15} className="text-white" />
            </div>
            <span className="text-white font-bold">StudentVoice</span>
            <span className="text-gray-600 text-sm ml-2">Founded by Kamei</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <Link to="/transparency" className="hover:text-gray-300 transition-colors">Transparency</Link>
            <Link to="/feed" className="hover:text-gray-300 transition-colors">Community</Link>
            <Link to="/innovations" className="hover:text-gray-300 transition-colors">Innovations</Link>
          </div>
          <p className="text-gray-600 text-sm">
            © 2025 StudentVoice. Real voices. Real change.
          </p>
        </div>
      </footer>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} defaultMode={authMode} />}
    </div>
  );
}
