import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowUp, ArrowDown, User, Loader2, Send, Flag, ArrowLeft } from 'lucide-react';
import { supabase, Post, Comment } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from '../lib/utils';

export default function PostDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [pollOptions, setPollOptions] = useState<{ id: string; option_text: string; vote_count: number }[]>([]);
  const [userPollVote, setUserPollVote] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    const fetchAll = async () => {
      const { data: p } = await supabase
        .from('posts')
        .select('*, profiles(*), categories(*)')
        .eq('id', id)
        .maybeSingle();
      if (p) {
        setPost(p as Post);
        await supabase.from('posts').update({ view_count: (p.view_count || 0) + 1 }).eq('id', id);
      }

      const { data: c } = await supabase
        .from('comments')
        .select('*, profiles(*)')
        .eq('post_id', id)
        .eq('is_removed', false)
        .order('created_at', { ascending: true });
      if (c) setComments(c as Comment[]);

      const { data: po } = await supabase
        .from('poll_options')
        .select('*')
        .eq('post_id', id);
      if (po) setPollOptions(po);

      if (user) {
        const { data: pv } = await supabase
          .from('poll_votes')
          .select('poll_option_id')
          .eq('post_id', id)
          .eq('user_id', user.id)
          .maybeSingle();
        if (pv) setUserPollVote(pv.poll_option_id);
      }

      setLoading(false);
    };
    fetchAll();
  }, [id, user]);

  const submitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !commentText.trim()) return;
    setSubmitting(true);
    await supabase.from('comments').insert({
      post_id: id,
      author_id: user.id,
      content: commentText.trim(),
    });
    const { data: c } = await supabase
      .from('comments')
      .select('*, profiles(*)')
      .eq('post_id', id)
      .eq('is_removed', false)
      .order('created_at', { ascending: true });
    if (c) setComments(c as Comment[]);
    setCommentText('');
    setSubmitting(false);
  };

  const votePoll = async (optionId: string) => {
    if (!user || userPollVote) return;
    await supabase.from('poll_votes').insert({ poll_option_id: optionId, user_id: user.id, post_id: id });
    await supabase.from('poll_options').update({ vote_count: (pollOptions.find(o => o.id === optionId)?.vote_count ?? 0) + 1 }).eq('id', optionId);
    setUserPollVote(optionId);
    setPollOptions(prev => prev.map(o => o.id === optionId ? { ...o, vote_count: o.vote_count + 1 } : o));
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-950 pt-20 flex items-center justify-center">
      <Loader2 className="text-blue-400 animate-spin" size={32} />
    </div>
  );

  if (!post) return (
    <div className="min-h-screen bg-gray-950 pt-20 flex items-center justify-center">
      <p className="text-gray-400">Post not found.</p>
    </div>
  );

  const totalPollVotes = pollOptions.reduce((a, o) => a + o.vote_count, 0);
  const author = post.is_anonymous ? null : post.profiles;

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <Link to="/feed" className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-6 text-sm">
          <ArrowLeft size={16} />
          Back to Feed
        </Link>

        <article className="bg-gray-900/50 border border-white/5 rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
              <User size={16} className="text-blue-400" />
            </div>
            <div>
              <span className="text-white text-sm font-medium">{author ? author.username : 'Anonymous'}</span>
              <span className="text-gray-500 text-xs ml-2">{formatDistanceToNow(post.created_at)}</span>
            </div>
            {post.categories && (
              <span className="ml-auto text-xs text-gray-500 bg-white/5 px-2 py-0.5 rounded-full">{post.categories.name}</span>
            )}
          </div>

          <h1 className="text-2xl font-bold text-white mb-4">{post.title}</h1>

          {post.content && <p className="text-gray-300 leading-relaxed mb-4 whitespace-pre-wrap">{post.content}</p>}

          {post.media_url && post.media_type === 'video' ? (
            <video
              src={post.media_url}
              controls
              className="w-full rounded-xl border border-white/5 mb-4"
            >
              Your browser does not support the video tag.
            </video>
          ) : post.media_url && post.media_type === 'image' ? (
            <img src={post.media_url} alt={post.title} className="w-full rounded-xl border border-white/5 mb-4" />
          ) : post.image_url && (
            <img src={post.image_url} alt={post.title} className="w-full rounded-xl border border-white/5 mb-4" />
          )}

          {post.post_type === 'poll' && pollOptions.length > 0 && (
            <div className="bg-gray-950/50 border border-white/5 rounded-xl p-4 mb-4">
              <p className="text-sm text-gray-400 mb-3">
                {userPollVote ? `${totalPollVotes} vote${totalPollVotes !== 1 ? 's' : ''} total` : 'Vote to see results'}
              </p>
              <div className="space-y-2">
                {pollOptions.map(opt => {
                  const pct = totalPollVotes ? Math.round((opt.vote_count / totalPollVotes) * 100) : 0;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => votePoll(opt.id)}
                      disabled={!!userPollVote}
                      className={`w-full text-left rounded-lg overflow-hidden border transition-all ${
                        userPollVote === opt.id ? 'border-blue-500/50' : 'border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="relative px-4 py-2.5">
                        {userPollVote && (
                          <div
                            className={`absolute inset-0 ${userPollVote === opt.id ? 'bg-blue-500/20' : 'bg-white/5'}`}
                            style={{ width: `${pct}%` }}
                          />
                        )}
                        <div className="relative flex justify-between items-center">
                          <span className="text-sm text-white">{opt.option_text}</span>
                          {userPollVote && <span className="text-xs text-gray-400">{pct}%</span>}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {post.tags.map(tag => (
                <span key={tag} className="text-xs text-blue-400 bg-blue-400/10 px-2 py-0.5 rounded-full">#{tag}</span>
              ))}
            </div>
          )}
        </article>

        {/* Comments */}
        <section>
          <h2 className="text-white font-semibold mb-4">{comments.length} Comments</h2>

          {user && (
            <form onSubmit={submitComment} className="mb-6">
              <div className="flex gap-3">
                <div className="flex-1 relative">
                  <textarea
                    value={commentText}
                    onChange={e => setCommentText(e.target.value)}
                    placeholder="Share your thoughts..."
                    rows={3}
                    className="w-full bg-gray-900/50 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  />
                </div>
              </div>
              <div className="flex justify-end mt-2">
                <button
                  type="submit"
                  disabled={submitting || !commentText.trim()}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
                >
                  {submitting ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                  Comment
                </button>
              </div>
            </form>
          )}

          <div className="space-y-3">
            {comments.map(comment => (
              <div key={comment.id} className="bg-gray-900/30 border border-white/5 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center">
                    <User size={12} className="text-gray-400" />
                  </div>
                  <span className="text-sm text-gray-300 font-medium">
                    {comment.is_anonymous ? 'Anonymous' : comment.profiles?.username}
                  </span>
                  <span className="text-xs text-gray-600">{formatDistanceToNow(comment.created_at)}</span>
                </div>
                <p className="text-gray-300 text-sm leading-relaxed">{comment.content}</p>
                <div className="flex items-center gap-3 mt-2">
                  <button className="flex items-center gap-1 text-xs text-gray-500 hover:text-blue-400 transition-colors">
                    <ArrowUp size={13} />
                    {comment.upvotes}
                  </button>
                  <button className="flex items-center gap-1 text-xs text-gray-500 hover:text-red-400 transition-colors">
                    <ArrowDown size={13} />
                  </button>
                  <button className="flex items-center gap-1 text-xs text-gray-500 hover:text-red-400 transition-colors ml-auto">
                    <Flag size={12} />
                    Report
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
