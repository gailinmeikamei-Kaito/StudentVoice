import { useState, useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { User, FileText, MessageSquare, Award, Calendar, Shield, Loader2, CreditCard as Edit2, Check, X } from 'lucide-react';
import { supabase, Profile as ProfileType, Post } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import PostCard from '../components/PostCard';
import { formatDistanceToNow } from '../lib/utils';

export default function Profile() {
  const { username } = useParams<{ username: string }>();
  const { user, profile: currentProfile, refreshProfile } = useAuth();
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);

  const isOwn = currentProfile?.username === username;

  useEffect(() => {
    const fetch = async () => {
      const { data: p } = await supabase
        .from('profiles')
        .select('*')
        .eq('username', username)
        .maybeSingle();
      if (!p) { setLoading(false); return; }
      setProfile(p);
      setDisplayName(p.display_name || '');
      setBio(p.bio || '');

      const { data: userPosts } = await supabase
        .from('posts')
        .select('*, profiles(*), categories(*)')
        .eq('author_id', p.id)
        .eq('is_removed', false)
        .eq('is_anonymous', false)
        .order('created_at', { ascending: false })
        .limit(20);
      if (userPosts) setPosts(userPosts as Post[]);
      setLoading(false);
    };
    fetch();
  }, [username]);

  const saveProfile = async () => {
    if (!user) return;
    setSaving(true);
    await supabase.from('profiles').update({ display_name: displayName, bio }).eq('id', user.id);
    await refreshProfile();
    setProfile(prev => prev ? { ...prev, display_name: displayName, bio } : prev);
    setEditing(false);
    setSaving(false);
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-950 pt-20 flex items-center justify-center">
      <Loader2 className="text-blue-400 animate-spin" size={32} />
    </div>
  );

  if (!profile) return <Navigate to="/feed" replace />;

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-gray-900/50 border border-white/5 rounded-2xl p-8 mb-6">
          <div className="flex items-start justify-between gap-6">
            <div className="flex items-center gap-5">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500/30 to-teal-500/30 border border-white/10 flex items-center justify-center">
                <User size={36} className="text-blue-400" />
              </div>
              <div>
                {editing ? (
                  <input
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    className="text-xl font-bold bg-gray-800 border border-white/20 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-blue-500 mb-1"
                  />
                ) : (
                  <h1 className="text-2xl font-bold text-white">{profile.display_name || profile.username}</h1>
                )}
                <p className="text-gray-400 text-sm">@{profile.username}</p>
                <div className="flex items-center gap-3 mt-2">
                  {profile.is_admin && (
                    <span className="inline-flex items-center gap-1 text-xs text-blue-400 bg-blue-400/10 px-2 py-0.5 rounded-full">
                      <Shield size={11} />
                      Admin
                    </span>
                  )}
                  {profile.is_verified && (
                    <span className="inline-flex items-center gap-1 text-xs text-green-400 bg-green-400/10 px-2 py-0.5 rounded-full">
                      <Check size={11} />
                      Verified
                    </span>
                  )}
                  <span className="inline-flex items-center gap-1 text-xs text-gray-500">
                    <Calendar size={11} />
                    Joined {formatDistanceToNow(profile.created_at)}
                  </span>
                </div>
              </div>
            </div>
            {isOwn && (
              <div className="flex items-center gap-2">
                {editing ? (
                  <>
                    <button onClick={saveProfile} disabled={saving} className="p-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-lg transition-colors">
                      {saving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                    </button>
                    <button onClick={() => setEditing(false)} className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors">
                      <X size={16} />
                    </button>
                  </>
                ) : (
                  <button onClick={() => setEditing(true)} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 px-3 py-2 rounded-lg transition-colors">
                    <Edit2 size={14} />
                    Edit Profile
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="mt-5">
            {editing ? (
              <textarea
                value={bio}
                onChange={e => setBio(e.target.value)}
                placeholder="Tell your story..."
                rows={3}
                className="w-full bg-gray-800 border border-white/20 rounded-lg px-3 py-2 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors resize-none"
              />
            ) : (
              <p className="text-gray-400 text-sm leading-relaxed">{profile.bio || 'No bio yet.'}</p>
            )}
          </div>

          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-white/5">
            <div className="text-center">
              <div className="text-xl font-bold text-white">{posts.length}</div>
              <div className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1"><FileText size={11} />Posts</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-white">{profile.reputation_points}</div>
              <div className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1"><Award size={11} />Reputation</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-white">0</div>
              <div className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1"><MessageSquare size={11} />Comments</div>
            </div>
          </div>
        </div>

        <h2 className="text-white font-semibold mb-4">Posts by {profile.username}</h2>
        {posts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">No public posts yet.</div>
        ) : (
          <div className="space-y-3">
            {posts.map(post => <PostCard key={post.id} post={post} />)}
          </div>
        )}
      </div>
    </div>
  );
}
