import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb, Plus, TrendingUp, Award, Zap, Loader2 } from 'lucide-react';
import { supabase, Post } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import PostCard from '../components/PostCard';
import AuthModal from '../components/AuthModal';

export default function Innovations() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const fetch = async () => {
      const { data, count: c } = await supabase
        .from('posts')
        .select('*, profiles(*), categories(*)', { count: 'exact' })
        .eq('post_type', 'innovation')
        .eq('is_removed', false)
        .order('upvotes', { ascending: false })
        .limit(50);
      if (data) setPosts(data as Post[]);
      if (c !== null) setCount(c);
      setLoading(false);
    };
    fetch();
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-b from-teal-950/30 to-gray-950 border-b border-white/5">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-900/20 via-transparent to-transparent" />
        <div className="relative max-w-5xl mx-auto px-4 py-16 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-400/10 border border-teal-400/20 rounded-2xl mb-6">
            <Lightbulb size={32} className="text-teal-400" />
          </div>
          <h1 className="text-4xl font-black text-white mb-3">Innovation Hub</h1>
          <p className="text-gray-400 text-lg max-w-xl mx-auto mb-6">
            Where students share inventions, startup ideas, and solutions to fix education.
          </p>
          <div className="flex items-center justify-center gap-8 mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-teal-400">{count}</div>
              <div className="text-xs text-gray-500">Ideas Submitted</div>
            </div>
          </div>
          {user ? (
            <Link
              to="/create"
              className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold px-6 py-3 rounded-xl transition-all"
            >
              <Plus size={18} />
              Share Your Innovation
            </Link>
          ) : (
            <button
              onClick={() => setShowAuth(true)}
              className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold px-6 py-3 rounded-xl transition-all"
            >
              <Plus size={18} />
              Share Your Innovation
            </button>
          )}
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Featured tags */}
        <div className="flex flex-wrap gap-2 mb-8">
          {['EdTech', 'AI Learning', 'Mental Health Tech', 'Student Rights', 'Gamified Education', 'Peer Teaching'].map(tag => (
            <span key={tag} className="text-xs text-teal-400 bg-teal-400/10 border border-teal-400/20 px-3 py-1.5 rounded-full cursor-pointer hover:bg-teal-400/20 transition-colors">
              {tag}
            </span>
          ))}
        </div>

        {/* Leaderboard highlights */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { icon: TrendingUp, label: 'Most Upvoted', color: 'text-blue-400', bg: 'bg-blue-400/10' },
            { icon: Award, label: 'Top Innovators', color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
            { icon: Zap, label: 'This Week', color: 'text-teal-400', bg: 'bg-teal-400/10' },
          ].map(({ icon: Icon, label, color, bg }) => (
            <div key={label} className={`${bg} border border-white/5 rounded-xl p-4 text-center`}>
              <Icon size={20} className={`${color} mx-auto mb-2`} />
              <span className="text-xs text-gray-400">{label}</span>
            </div>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="text-teal-400 animate-spin" size={32} />
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-20">
            <Lightbulb size={40} className="text-gray-700 mx-auto mb-4" />
            <p className="text-gray-400 text-lg font-medium">No innovations yet</p>
            <p className="text-gray-600 text-sm mt-1">Be the first to share your idea!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {posts.map(post => <PostCard key={post.id} post={post} />)}
          </div>
        )}
      </div>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} defaultMode="signup" />}
    </div>
  );
}
