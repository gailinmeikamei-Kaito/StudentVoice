import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { Bell, Check, Loader2, MessageSquare, ArrowUp, Shield } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from '../lib/utils';

type Notification = {
  id: string;
  type: string;
  title: string;
  message: string;
  link: string;
  is_read: boolean;
  created_at: string;
};

const typeIcons: Record<string, typeof Bell> = {
  comment: MessageSquare,
  upvote: ArrowUp,
  admin: Shield,
  default: Bell,
};

export default function Notifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  if (!user) return <Navigate to="/" replace />;

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);
      if (data) setNotifications(data);
      setLoading(false);
    };
    fetch();
  }, [user]);

  const markAllRead = async () => {
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  };

  const markRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">Notifications</h1>
            {unreadCount > 0 && (
              <p className="text-sm text-gray-400 mt-1">{unreadCount} unread</p>
            )}
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="flex items-center gap-2 text-sm text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 px-4 py-2 rounded-lg transition-colors"
            >
              <Check size={14} />
              Mark all read
            </button>
          )}
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="animate-spin text-blue-400" size={32} />
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-20">
            <Bell size={40} className="text-gray-700 mx-auto mb-4" />
            <p className="text-gray-400 text-lg font-medium">No notifications yet</p>
            <p className="text-gray-600 text-sm mt-1">You'll be notified when others interact with your posts.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map(notification => {
              const Icon = typeIcons[notification.type] || typeIcons.default;
              return (
                <button
                  key={notification.id}
                  onClick={() => markRead(notification.id)}
                  className={`w-full text-left flex items-start gap-4 p-4 rounded-xl border transition-all ${
                    notification.is_read
                      ? 'bg-gray-900/30 border-white/5'
                      : 'bg-blue-500/5 border-blue-500/20'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    notification.is_read ? 'bg-gray-800' : 'bg-blue-500/20'
                  }`}>
                    <Icon size={18} className={notification.is_read ? 'text-gray-500' : 'text-blue-400'} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium ${notification.is_read ? 'text-gray-300' : 'text-white'}`}>
                      {notification.title}
                    </p>
                    {notification.message && (
                      <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{notification.message}</p>
                    )}
                    <p className="text-xs text-gray-600 mt-1">{formatDistanceToNow(notification.created_at)}</p>
                  </div>
                  {!notification.is_read && (
                    <div className="w-2 h-2 bg-blue-400 rounded-full flex-shrink-0 mt-2" />
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
