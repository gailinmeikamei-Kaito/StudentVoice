import { useState, useRef, useEffect } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { FileText, Image, Smile, BarChart2, Lightbulb, Plus, Trash2, Loader2, Tag, Upload, X, Film, ImagePlus } from 'lucide-react';
import { supabase, Category } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { uploadMedia, validateFile } from '../lib/media';

type PostType = 'text' | 'image' | 'meme' | 'poll' | 'innovation';

const typeConfig: Record<PostType, { icon: typeof FileText; label: string; desc: string; color: string }> = {
  text: { icon: FileText, label: 'Discussion', desc: 'Share thoughts & opinions', color: 'text-blue-400' },
  image: { icon: Image, label: 'Image Post', desc: 'Share an image', color: 'text-green-400' },
  meme: { icon: Smile, label: 'Meme', desc: 'Relatable student content', color: 'text-pink-400' },
  poll: { icon: BarChart2, label: 'Poll', desc: 'Get student opinions', color: 'text-yellow-400' },
  innovation: { icon: Lightbulb, label: 'Innovation', desc: 'Share your idea or solution', color: 'text-teal-400' },
};

export default function CreatePost() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [type, setType] = useState<PostType>('text');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [pollOptions, setPollOptions] = useState(['', '']);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Direct upload state
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [uploadedFile, setUploadedFile] = useState<{ url: string; type: 'image' | 'video'; name: string } | null>(null);
  const [fileError, setFileError] = useState('');

  useEffect(() => {
    supabase.from('categories').select('*').order('name').then(({ data }) => {
      if (data) setCategories(data);
    });
  }, []);

  if (!user) return <Navigate to="/" replace />;

  const addTag = () => {
    const t = tagInput.trim().toLowerCase().replace(/\s+/g, '_');
    if (t && !tags.includes(t) && tags.length < 5) {
      setTags([...tags, t]);
      setTagInput('');
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileError('');

    const validation = validateFile(file);
    if (!validation.valid) {
      setFileError(validation.error || 'Invalid file');
      return;
    }

    setUploading(true);
    setUploadProgress(`Uploading ${file.name}...`);

    try {
      const result = await uploadMedia(file, user.id);
      setUploadedFile({ url: result.url, type: result.type, name: file.name });
      setImageUrl(result.url);
    } catch (err) {
      setFileError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
      setUploadProgress('');
    }
  };

  const removeUploadedFile = () => {
    setUploadedFile(null);
    setImageUrl('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) { setError('Title is required'); return; }
    setLoading(true);
    setError('');

    const mediaType = uploadedFile ? uploadedFile.type : (imageUrl ? 'image' : '');

    const { data: post, error: postError } = await supabase
      .from('posts')
      .insert({
        author_id: user.id,
        title: title.trim(),
        content: content.trim(),
        post_type: type,
        image_url: imageUrl.trim(),
        media_url: uploadedFile ? uploadedFile.url : '',
        media_type: mediaType,
        category_id: categoryId || null,
        is_anonymous: isAnonymous,
        tags,
      })
      .select()
      .single();

    if (postError) { setError(postError.message); setLoading(false); return; }

    if (type === 'poll' && post) {
      const validOptions = pollOptions.filter(o => o.trim());
      if (validOptions.length >= 2) {
        await supabase.from('poll_options').insert(
          validOptions.map(opt => ({ post_id: post.id, option_text: opt.trim() }))
        );
      }
    }

    navigate(`/post/${post.id}`);
  };

  const showMediaUpload = type === 'image' || type === 'meme' || type === 'innovation';

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-white mb-8">Create a Post</h1>

        {/* Type selector */}
        <div className="grid grid-cols-5 gap-2 mb-6">
          {(Object.keys(typeConfig) as PostType[]).map(t => {
            const { icon: Icon, label, color } = typeConfig[t];
            return (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all ${
                  type === t ? 'border-blue-500/50 bg-blue-500/10' : 'border-white/5 bg-gray-900/50 hover:border-white/10'
                }`}
              >
                <Icon size={18} className={type === t ? color : 'text-gray-500'} />
                <span className={`text-xs font-medium ${type === t ? 'text-white' : 'text-gray-500'}`}>{label}</span>
              </button>
            );
          })}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Title — be clear and honest"
              maxLength={200}
              required
              className="w-full bg-gray-900/50 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          {(type === 'text' || type === 'innovation') && (
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder={type === 'innovation' ? 'Describe your idea, the problem it solves, and how it works...' : 'Share your thoughts, experience, or opinion...'}
              rows={6}
              className="w-full bg-gray-900/50 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors resize-none"
            />
          )}

          {/* Media Upload Section */}
          {showMediaUpload && (
            <div className="space-y-3">
              {/* Drop zone / upload area */}
              <div
                onClick={() => !uploading && fileInputRef.current?.click()}
                onDragOver={e => { e.preventDefault(); e.stopPropagation(); }}
                onDrop={e => {
                  e.preventDefault();
                  e.stopPropagation();
                  const file = e.dataTransfer.files[0];
                  if (file) {
                    const dt = new DataTransfer();
                    dt.items.add(file);
                    if (fileInputRef.current) {
                      fileInputRef.current.files = dt.files;
                      fileInputRef.current.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                  }
                }}
                className={`relative border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                  uploading
                    ? 'border-blue-500/50 bg-blue-500/5'
                    : uploadedFile
                    ? 'border-green-500/30 bg-green-500/5'
                    : 'border-white/10 bg-gray-900/30 hover:border-blue-500/30 hover:bg-blue-500/5'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,video/quicktime"
                  onChange={handleFileSelect}
                  className="hidden"
                />

                {uploading ? (
                  <div className="flex flex-col items-center gap-3">
                    <Loader2 size={32} className="text-blue-400 animate-spin" />
                    <p className="text-blue-300 text-sm font-medium">{uploadProgress}</p>
                  </div>
                ) : uploadedFile ? (
                  <div className="space-y-3">
                    {uploadedFile.type === 'image' ? (
                      <img
                        src={uploadedFile.url}
                        alt="Preview"
                        className="max-h-64 mx-auto rounded-lg object-contain"
                      />
                    ) : (
                      <video
                        src={uploadedFile.url}
                        controls
                        className="max-h-64 mx-auto rounded-lg"
                      >
                        Your browser does not support the video tag.
                      </video>
                    )}
                    <p className="text-green-400 text-sm font-medium">{uploadedFile.name}</p>
                    <button
                      type="button"
                      onClick={e => { e.stopPropagation(); removeUploadedFile(); }}
                      className="inline-flex items-center gap-1.5 text-xs text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      <X size={12} />
                      Remove
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                        <ImagePlus size={24} className="text-blue-400" />
                      </div>
                      <div className="w-12 h-12 rounded-xl bg-teal-500/10 flex items-center justify-center">
                        <Film size={24} className="text-teal-400" />
                      </div>
                    </div>
                    <div>
                      <p className="text-white font-medium text-sm">Click to upload or drag and drop</p>
                      <p className="text-gray-500 text-xs mt-1">
                        Images (JPG, PNG, GIF, WebP up to 10MB) or Videos (MP4, WebM, MOV up to 50MB)
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {fileError && (
                <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-2">{fileError}</p>
              )}

              {/* Or paste URL */}
              <div className="relative">
                <div className="absolute inset-x-0 top-1/2 h-px bg-white/5" />
                <div className="relative flex justify-center">
                  <span className="bg-gray-950 px-3 text-xs text-gray-500">or paste image URL</span>
                </div>
              </div>
              <input
                type="url"
                value={uploadedFile ? '' : imageUrl}
                onChange={e => { setImageUrl(e.target.value); if (uploadedFile) removeUploadedFile(); }}
                placeholder="https://example.com/image.jpg"
                disabled={!!uploadedFile}
                className="w-full bg-gray-900/50 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors disabled:opacity-50"
              />
            </div>
          )}

          {type === 'poll' && (
            <div className="space-y-2">
              <label className="text-sm text-gray-400">Poll Options (min 2)</label>
              {pollOptions.map((opt, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    type="text"
                    value={opt}
                    onChange={e => {
                      const updated = [...pollOptions];
                      updated[i] = e.target.value;
                      setPollOptions(updated);
                    }}
                    placeholder={`Option ${i + 1}`}
                    className="flex-1 bg-gray-900/50 border border-white/10 rounded-lg px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                  />
                  {pollOptions.length > 2 && (
                    <button type="button" onClick={() => setPollOptions(pollOptions.filter((_, idx) => idx !== i))} className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
              ))}
              {pollOptions.length < 6 && (
                <button type="button" onClick={() => setPollOptions([...pollOptions, ''])} className="flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300 transition-colors">
                  <Plus size={14} />
                  Add Option
                </button>
              )}
            </div>
          )}

          <div>
            <select
              value={categoryId}
              onChange={e => setCategoryId(e.target.value)}
              className="w-full bg-gray-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            >
              <option value="">Select category (optional)</option>
              {categories.map(cat => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          {/* Tags */}
          <div>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  value={tagInput}
                  onChange={e => setTagInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
                  placeholder="Add tags (press Enter)"
                  className="w-full bg-gray-900/50 border border-white/10 rounded-lg pl-8 pr-4 py-2.5 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
              <button type="button" onClick={addTag} className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm text-gray-300 transition-colors">
                Add
              </button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map(tag => (
                  <span key={tag} className="flex items-center gap-1 text-xs text-blue-400 bg-blue-400/10 px-2 py-1 rounded-full">
                    #{tag}
                    <button onClick={() => setTags(tags.filter(t => t !== tag))} className="hover:text-red-400 transition-colors">×</button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Anonymous toggle */}
          <label className="flex items-center gap-3 cursor-pointer">
            <div
              onClick={() => setIsAnonymous(!isAnonymous)}
              className={`w-10 h-5 rounded-full transition-colors ${isAnonymous ? 'bg-blue-600' : 'bg-gray-700'} relative`}
            >
              <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full transition-transform ${isAnonymous ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </div>
            <span className="text-sm text-gray-400">Post anonymously</span>
          </label>

          {error && (
            <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-2">{error}</p>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="flex-1 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 font-medium py-3 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || uploading}
              className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-xl transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={16} className="animate-spin" />}
              Publish Post
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
