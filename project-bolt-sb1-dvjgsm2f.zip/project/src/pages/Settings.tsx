import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Settings as SettingsIcon, Eye, EyeOff, Loader2, Check, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

export default function Settings() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [anonymousMode, setAnonymousMode] = useState(profile?.anonymous_mode ?? false);
  const [newPassword, setNewPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [pwMsg, setPwMsg] = useState('');

  if (!user || !profile) return <Navigate to="/" replace />;

  const savePreferences = async () => {
    setSaving(true);
    await supabase.from('profiles').update({ anonymous_mode: anonymousMode }).eq('id', user.id);
    await refreshProfile();
    setSaved(true);
    setSaving(false);
    setTimeout(() => setSaved(false), 2000);
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) { setPwMsg('Password must be at least 6 characters'); return; }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) setPwMsg(error.message);
    else { setPwMsg('Password updated successfully!'); setNewPassword(''); }
  };

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-gray-800 rounded-xl flex items-center justify-center">
            <SettingsIcon size={20} className="text-gray-400" />
          </div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
        </div>

        <div className="space-y-4">
          {/* Account info */}
          <div className="bg-gray-900/50 border border-white/5 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-4">Account</h2>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Username</span>
                <span className="text-white text-sm font-medium">@{profile.username}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Email</span>
                <span className="text-white text-sm">{user.email}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Reputation</span>
                <span className="text-blue-400 text-sm font-medium">{profile.reputation_points} pts</span>
              </div>
              {profile.is_admin && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Role</span>
                  <span className="text-blue-400 text-sm font-medium">Administrator</span>
                </div>
              )}
            </div>
          </div>

          {/* Privacy */}
          <div className="bg-gray-900/50 border border-white/5 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-4">Privacy</h2>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm font-medium">Anonymous Mode</p>
                <p className="text-gray-500 text-xs mt-0.5">Post anonymously by default</p>
              </div>
              <button
                onClick={() => setAnonymousMode(!anonymousMode)}
                className={`w-11 h-6 rounded-full transition-colors relative ${anonymousMode ? 'bg-blue-600' : 'bg-gray-700'}`}
              >
                <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${anonymousMode ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>
            <button
              onClick={savePreferences}
              disabled={saving}
              className="mt-4 flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              {saving ? <Loader2 size={14} className="animate-spin" /> : saved ? <Check size={14} /> : null}
              {saved ? 'Saved!' : 'Save Preferences'}
            </button>
          </div>

          {/* Change password */}
          <div className="bg-gray-900/50 border border-white/5 rounded-2xl p-6">
            <h2 className="text-white font-semibold mb-4">Change Password</h2>
            <form onSubmit={changePassword} className="space-y-3">
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="New password"
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 pr-10 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {pwMsg && (
                <p className={`text-sm px-3 py-2 rounded-lg ${pwMsg.includes('success') ? 'text-green-400 bg-green-500/10' : 'text-red-400 bg-red-500/10'}`}>
                  {pwMsg}
                </p>
              )}
              <button type="submit" className="bg-gray-700 hover:bg-gray-600 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
                Update Password
              </button>
            </form>
          </div>

          {/* Danger */}
          <div className="bg-gray-900/50 border border-red-500/10 rounded-2xl p-6">
            <h2 className="text-red-400 font-semibold mb-4">Danger Zone</h2>
            <button
              onClick={signOut}
              className="flex items-center gap-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-sm font-medium px-4 py-2 rounded-lg transition-colors"
            >
              <LogOut size={14} />
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
