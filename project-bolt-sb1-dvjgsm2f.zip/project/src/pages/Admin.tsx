import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import {
  Shield, Users, FileText, Flag, CheckCircle, XCircle,
  Loader2, RefreshCw, Eye, Trash2, Pin
} from 'lucide-react';
import { supabase, Post, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow, formatNumber } from '../lib/utils';

type Report = {
  id: string;
  reason: string;
  status: string;
  created_at: string;
  reporter_id: string;
  post_id: string | null;
  comment_id: string | null;
  posts?: { title: string };
};

export default function Admin() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<'overview' | 'reports' | 'users' | 'posts'>('overview');
  const [reports, setReports] = useState<Report[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [counts, setCounts] = useState({ members: 0, posts: 0, reports: 0, resolved: 0 });

  if (!profile?.is_admin) return <Navigate to="/" replace />;

  const fetchData = async () => {
    setLoading(true);
    const [
      { count: members },
      { count: postCount },
      { count: pending },
      { count: resolved },
    ] = await Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('posts').select('*', { count: 'exact', head: true }).eq('is_removed', false),
      supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'resolved'),
    ]);
    setCounts({ members: members ?? 0, posts: postCount ?? 0, reports: pending ?? 0, resolved: resolved ?? 0 });

    if (tab === 'reports') {
      const { data } = await supabase
        .from('reports')
        .select('*, posts(title)')
        .order('created_at', { ascending: false })
        .limit(50);
      if (data) setReports(data as Report[]);
    }
    if (tab === 'users') {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);
      if (data) setUsers(data);
    }
    if (tab === 'posts') {
      const { data } = await supabase
        .from('posts')
        .select('*, profiles(*), categories(*)')
        .order('created_at', { ascending: false })
        .limit(50);
      if (data) setPosts(data as Post[]);
    }
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [tab]);

  const resolveReport = async (id: string) => {
    await supabase.from('reports').update({ status: 'resolved', resolved_by: profile?.id }).eq('id', id);
    fetchData();
  };

  const dismissReport = async (id: string) => {
    await supabase.from('reports').update({ status: 'dismissed' }).eq('id', id);
    fetchData();
  };

  const removePost = async (postId: string) => {
    await supabase.from('posts').update({ is_removed: true }).eq('id', postId);
    fetchData();
  };

  const pinPost = async (postId: string, pinned: boolean) => {
    await supabase.from('posts').update({ is_pinned: !pinned }).eq('id', postId);
    fetchData();
  };

  const verifyUser = async (userId: string, verified: boolean) => {
    await supabase.from('profiles').update({ is_verified: !verified }).eq('id', userId);
    fetchData();
  };

  const tabs = [
    { key: 'overview', label: 'Overview' },
    { key: 'reports', label: `Reports (${counts.reports})` },
    { key: 'users', label: 'Users' },
    { key: 'posts', label: 'Posts' },
  ] as const;

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-blue-500/20 border border-blue-500/30 rounded-xl flex items-center justify-center">
            <Shield size={20} className="text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
            <p className="text-gray-500 text-sm">Logged in as {profile.username}</p>
          </div>
          <button onClick={fetchData} className="ml-auto p-2 text-gray-400 hover:text-white transition-colors">
            <RefreshCw size={16} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-900/50 border border-white/5 rounded-xl p-1 mb-6 w-fit">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                tab === t.key ? 'bg-blue-500/20 text-blue-400' : 'text-gray-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="animate-spin text-blue-400" size={32} /></div>
        ) : (
          <>
            {tab === 'overview' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { icon: Users, label: 'Total Members', value: counts.members, color: 'text-blue-400' },
                  { icon: FileText, label: 'Active Posts', value: counts.posts, color: 'text-green-400' },
                  { icon: Flag, label: 'Pending Reports', value: counts.reports, color: 'text-red-400' },
                  { icon: CheckCircle, label: 'Reports Resolved', value: counts.resolved, color: 'text-emerald-400' },
                ].map(({ icon: Icon, label, value, color }) => (
                  <div key={label} className="bg-gray-900/50 border border-white/5 rounded-xl p-5 text-center">
                    <Icon size={24} className={`${color} mx-auto mb-3`} />
                    <div className={`text-3xl font-black ${color}`}>{formatNumber(value)}</div>
                    <div className="text-xs text-gray-500 mt-1">{label}</div>
                  </div>
                ))}
              </div>
            )}

            {tab === 'reports' && (
              <div className="space-y-3">
                {reports.length === 0 ? (
                  <p className="text-center text-gray-500 py-12">No reports found.</p>
                ) : reports.map(report => (
                  <div key={report.id} className={`bg-gray-900/50 border rounded-xl p-4 ${report.status === 'pending' ? 'border-red-500/20' : 'border-white/5'}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            report.status === 'pending' ? 'bg-red-400/10 text-red-400' :
                            report.status === 'resolved' ? 'bg-green-400/10 text-green-400' :
                            'bg-gray-400/10 text-gray-400'
                          }`}>{report.status}</span>
                          <span className="text-xs text-gray-500">{formatDistanceToNow(report.created_at)}</span>
                        </div>
                        <p className="text-white text-sm font-medium">{report.reason}</p>
                        {report.posts && <p className="text-gray-500 text-xs mt-1">Post: {report.posts.title}</p>}
                      </div>
                      {report.status === 'pending' && (
                        <div className="flex items-center gap-2">
                          <button onClick={() => resolveReport(report.id)} className="p-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-lg transition-colors">
                            <CheckCircle size={15} />
                          </button>
                          <button onClick={() => dismissReport(report.id)} className="p-1.5 bg-gray-500/20 hover:bg-gray-500/30 text-gray-400 rounded-lg transition-colors">
                            <XCircle size={15} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === 'users' && (
              <div className="space-y-2">
                {users.map(u => (
                  <div key={u.id} className="bg-gray-900/50 border border-white/5 rounded-xl px-4 py-3 flex items-center justify-between">
                    <div>
                      <span className="text-white font-medium text-sm">@{u.username}</span>
                      <span className="text-gray-500 text-xs ml-2">{formatDistanceToNow(u.created_at)}</span>
                      {u.is_admin && <span className="ml-2 text-xs text-blue-400 bg-blue-400/10 px-1.5 py-0.5 rounded">Admin</span>}
                      {u.is_verified && <span className="ml-2 text-xs text-green-400 bg-green-400/10 px-1.5 py-0.5 rounded">Verified</span>}
                    </div>
                    <button
                      onClick={() => verifyUser(u.id, u.is_verified)}
                      className={`text-xs px-3 py-1.5 rounded-lg transition-colors ${
                        u.is_verified ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20' : 'bg-green-500/10 text-green-400 hover:bg-green-500/20'
                      }`}
                    >
                      {u.is_verified ? 'Unverify' : 'Verify'}
                    </button>
                  </div>
                ))}
              </div>
            )}

            {tab === 'posts' && (
              <div className="space-y-2">
                {posts.map(p => (
                  <div key={p.id} className={`bg-gray-900/50 border rounded-xl px-4 py-3 flex items-center justify-between ${p.is_removed ? 'opacity-50 border-red-500/10' : 'border-white/5'}`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium line-clamp-1">{p.title}</p>
                      <p className="text-gray-500 text-xs mt-0.5">
                        {p.post_type} · {formatDistanceToNow(p.created_at)} · {p.upvotes} upvotes
                      </p>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <button onClick={() => pinPost(p.id, p.is_pinned)} className={`p-1.5 rounded-lg transition-colors ${p.is_pinned ? 'bg-yellow-500/20 text-yellow-400' : 'bg-white/5 text-gray-500 hover:text-yellow-400'}`}>
                        <Pin size={14} />
                      </button>
                      <button onClick={() => removePost(p.id)} disabled={p.is_removed} className="p-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors disabled:opacity-30">
                        <Trash2 size={14} />
                      </button>
                      <a href={`/post/${p.id}`} className="p-1.5 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors">
                        <Eye size={14} />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
