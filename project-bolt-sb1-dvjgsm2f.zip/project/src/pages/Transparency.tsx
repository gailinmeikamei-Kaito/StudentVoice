import { useEffect, useState } from 'react';
import {
  CheckCircle, Users, FileText, MessageSquare, Lightbulb,
  Smile, BarChart2, Shield, TrendingUp, Eye, RefreshCw, Loader2
} from 'lucide-react';
import { useStats } from '../hooks/useStats';
import { supabase } from '../lib/supabase';
import { formatNumber, formatDistanceToNow } from '../lib/utils';

type TopPost = { id: string; title: string; upvotes: number; comment_count: number; created_at: string };

export default function Transparency() {
  const { stats, loading, refetch } = useStats();
  const [topPosts, setTopPosts] = useState<TopPost[]>([]);
  const [topPostsLoading, setTopPostsLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    const fetchTop = async () => {
      const { data } = await supabase
        .from('posts')
        .select('id, title, upvotes, comment_count, created_at')
        .eq('is_removed', false)
        .order('upvotes', { ascending: false })
        .limit(5);
      if (data) setTopPosts(data as TopPost[]);
      setTopPostsLoading(false);
    };
    fetchTop();
  }, []);

  const handleRefresh = () => {
    refetch();
    setLastUpdated(new Date());
  };

  const statRows = [
    { icon: Users, label: 'Total Registered Members', value: stats.totalMembers, color: 'text-blue-400', note: 'Real account count from profiles table' },
    { icon: Eye, label: 'Weekly Active Users', value: stats.recentlyActive, color: 'text-cyan-400', note: 'Users seen within last 7 days' },
    { icon: FileText, label: 'Total Posts Published', value: stats.totalPosts, color: 'text-green-400', note: 'All non-removed posts' },
    { icon: MessageSquare, label: 'Total Comments', value: stats.totalComments, color: 'text-teal-400', note: 'All non-removed comments' },
    { icon: Lightbulb, label: 'Innovation Ideas', value: stats.totalInnovations, color: 'text-yellow-400', note: 'Posts of type "innovation"' },
    { icon: Smile, label: 'Memes Uploaded', value: stats.totalMemes, color: 'text-pink-400', note: 'Posts of type "meme"' },
    { icon: BarChart2, label: 'Polls Created', value: stats.totalPolls, color: 'text-orange-400', note: 'Posts of type "poll"' },
    { icon: Shield, label: 'Reports Resolved', value: stats.reportsResolved, color: 'text-emerald-400', note: 'Moderation actions completed' },
  ];

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      {/* Header */}
      <div className="border-b border-white/5 bg-gray-900/30">
        <div className="max-w-5xl mx-auto px-4 py-12 text-center">
          <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-4 py-2 mb-5">
            <CheckCircle size={14} className="text-green-400" />
            <span className="text-sm text-green-300 font-medium">Community Transparency Dashboard</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-3">Real Numbers Only</h1>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Every stat on this page is pulled directly from our database in real time.
            We never inflate, fake, or estimate our community numbers.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-10">
        {/* Refresh */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-gray-500">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </p>
          <button
            onClick={handleRefresh}
            className="flex items-center gap-2 text-sm text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2 rounded-lg transition-colors"
          >
            <RefreshCw size={14} />
            Refresh
          </button>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
          {statRows.map(({ icon: Icon, label, value, color, note }) => (
            <div key={label} className="bg-gray-900/50 border border-white/5 rounded-xl p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center flex-shrink-0">
                <Icon size={22} className={color} />
              </div>
              <div className="flex-1">
                <div className="flex items-baseline gap-2">
                  <span className={`text-2xl font-black ${color}`}>
                    {loading ? <Loader2 size={18} className="animate-spin inline" /> : formatNumber(value)}
                  </span>
                </div>
                <div className="text-white text-sm font-medium">{label}</div>
                <div className="text-gray-600 text-xs mt-0.5">{note}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Top posts */}
        <div className="bg-gray-900/50 border border-white/5 rounded-2xl p-6 mb-8">
          <h2 className="text-white font-bold text-lg mb-5 flex items-center gap-2">
            <TrendingUp size={18} className="text-blue-400" />
            Most Discussed Posts
          </h2>
          {topPostsLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="animate-spin text-gray-500" size={24} /></div>
          ) : topPosts.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-8">No posts yet.</p>
          ) : (
            <div className="space-y-3">
              {topPosts.map((post, i) => (
                <div key={post.id} className="flex items-center gap-4">
                  <span className="text-2xl font-black text-gray-700 w-6 text-center">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium line-clamp-1">{post.title}</p>
                    <p className="text-gray-500 text-xs mt-0.5">{formatDistanceToNow(post.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-500 flex-shrink-0">
                    <span className="text-blue-400 font-medium">{post.upvotes} upvotes</span>
                    <span>{post.comment_count} comments</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Policy note */}
        <div className="bg-blue-500/5 border border-blue-500/20 rounded-2xl p-6">
          <h3 className="text-white font-bold mb-3 flex items-center gap-2">
            <Shield size={18} className="text-blue-400" />
            Our Transparency Commitment
          </h3>
          <ul className="space-y-2 text-sm text-gray-400">
            {[
              'All member counts reflect actual registered accounts — no bots, no fake profiles.',
              'Post and comment counts exclude removed content reported by our community.',
              'Active user numbers use real last-seen timestamps, not estimates.',
              'We do not purchase engagement or run fake ad campaigns.',
              'This page refreshes its data from the live database on demand.',
              'Founded by Kamei — built on the principle that student trust is everything.',
            ].map(item => (
              <li key={item} className="flex items-start gap-2">
                <CheckCircle size={14} className="text-green-400 mt-0.5 flex-shrink-0" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
