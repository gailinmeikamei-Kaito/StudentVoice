import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Smile, Plus, ArrowUp, MessageSquare, Loader2 } from 'lucide-react';
import { supabase, Post } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import AuthModal from '../components/AuthModal';
import { formatDistanceToNow } from '../lib/utils';

export default function Memes() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('posts')
        .select('*, profiles(*), categories(*)')
        .eq('post_type', 'meme')
        .eq('is_removed', false)
        .order('created_at', { ascending: false })
        .limit(50);
      if (data) setPosts(data as Post[]);
      setLoading(false);
    };
    fetch();
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-b from-pink-950/20 to-gray-950 border-b border-white/5">
        <div className="relative max-w-5xl mx-auto px-4 py-14 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-pink-400/10 border border-pink-400/20 rounded-2xl mb-5">
            <Smile size={32} className="text-pink-400" />
          </div>
          <h1 className="text-4xl font-black text-white mb-3">Meme Zone</h1>
          <p className="text-gray-400 text-lg max-w-xl mx-auto mb-6">
            Relatable student life. Because sometimes you just have to laugh.
          </p>
          {user ? (
            <Link
              to="/create"
              className="inline-flex items-center gap-2 bg-pink-600 hover:bg-pink-500 text-white font-semibold px-6 py-3 rounded-xl transition-all"
            >
              <Plus size={18} />
              Upload a Meme
            </Link>
          ) : (
            <button
              onClick={() => setShowAuth(true)}
              className="inline-flex items-center gap-2 bg-pink-600 hover:bg-pink-500 text-white font-semibold px-6 py-3 rounded-xl transition-all"
            >
              <Plus size={18} />
              Upload a Meme
            </button>
          )}
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="text-pink-400 animate-spin" size={32} />
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-20">
            <Smile size={48} className="text-gray-700 mx-auto mb-4" />
            <p className="text-gray-400 text-lg font-medium">No memes yet — this is a crisis</p>
            <p className="text-gray-600 text-sm mt-1">Be a hero. Upload the first meme.</p>
          </div>
        ) : (
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
            {posts.map(post => (
              <div key={post.id} className="break-inside-avoid bg-gray-900/50 border border-white/5 rounded-xl overflow-hidden hover:border-white/10 transition-all">
                {post.media_url && post.media_type === 'video' ? (
                  <Link to={`/post/${post.id}`}>
                    <video
                      src={post.media_url}
                      preload="metadata"
                      className="w-full object-cover"
                    >
                      Your browser does not support the video tag.
                    </video>
                  </Link>
                ) : post.media_url && post.media_type === 'image' ? (
                  <Link to={`/post/${post.id}`}>
                    <img src={post.media_url} alt={post.title} className="w-full object-cover" loading="lazy" />
                  </Link>
                ) : post.image_url && (
                  <Link to={`/post/${post.id}`}>
                    <img src={post.image_url} alt={post.title} className="w-full object-cover" loading="lazy" />
                  </Link>
                )}
                <div className="p-3">
                  <Link to={`/post/${post.id}`}>
                    <p className="text-white text-sm font-medium line-clamp-2 mb-2">{post.title}</p>
                  </Link>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{post.is_anonymous ? 'Anonymous' : post.profiles?.username}</span>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1"><ArrowUp size={11} />{post.upvotes}</span>
                      <span className="flex items-center gap-1"><MessageSquare size={11} />{post.comment_count}</span>
                      <span>{formatDistanceToNow(post.created_at)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} defaultMode="signup" />}
    </div>
  );
}
