import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Clock, Flame, Plus, Filter, Search, Loader2 } from 'lucide-react';
import { supabase, Post, Category } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import PostCard from '../components/PostCard';
import AuthModal from '../components/AuthModal';

type SortMode = 'trending' | 'new' | 'top';

export default function Feed() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState<SortMode>('new');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [showAuth, setShowAuth] = useState(false);

  const fetchCategories = async () => {
    const { data } = await supabase.from('categories').select('*').order('name');
    if (data) setCategories(data);
  };

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    let q = supabase
      .from('posts')
      .select('*, profiles(*), categories(*)')
      .eq('is_removed', false);

    if (selectedCategory) q = q.eq('category_id', selectedCategory);
    if (search) q = q.ilike('title', `%${search}%`);

    if (sort === 'new') q = q.order('created_at', { ascending: false });
    else if (sort === 'top') q = q.order('upvotes', { ascending: false });
    else q = q.order('comment_count', { ascending: false });

    const { data } = await q.limit(50);
    if (data) setPosts(data as Post[]);
    setLoading(false);
  }, [sort, selectedCategory, search]);

  useEffect(() => { fetchCategories(); }, []);
  useEffect(() => { fetchPosts(); }, [fetchPosts]);

  const sortOptions: { key: SortMode; icon: typeof TrendingUp; label: string }[] = [
    { key: 'new', icon: Clock, label: 'New' },
    { key: 'trending', icon: TrendingUp, label: 'Trending' },
    { key: 'top', icon: Flame, label: 'Top' },
  ];

  return (
    <div className="min-h-screen bg-gray-950 pt-20">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="w-full lg:w-64 flex-shrink-0">
            <div className="bg-gray-900/50 border border-white/5 rounded-xl p-4 sticky top-24">
              <h3 className="text-white font-semibold text-sm mb-4">Categories</h3>
              <button
                onClick={() => setSelectedCategory(null)}
                className={`w-full text-left text-sm px-3 py-2 rounded-lg transition-colors mb-1 ${!selectedCategory ? 'bg-blue-500/20 text-blue-400' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
              >
                All Discussions
              </button>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`w-full text-left text-sm px-3 py-2 rounded-lg transition-colors mb-1 ${selectedCategory === cat.id ? 'bg-blue-500/20 text-blue-400' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </aside>

          {/* Main */}
          <main className="flex-1 min-w-0">
            {/* Header */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <div className="relative flex-1">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  placeholder="Search discussions..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full bg-gray-900/50 border border-white/10 rounded-lg pl-9 pr-4 py-2.5 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
              <div className="flex items-center gap-2 bg-gray-900/50 border border-white/5 rounded-lg p-1">
                {sortOptions.map(({ key, icon: Icon, label }) => (
                  <button
                    key={key}
                    onClick={() => setSort(key)}
                    className={`flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md transition-colors ${sort === key ? 'bg-blue-500/20 text-blue-400' : 'text-gray-400 hover:text-white'}`}
                  >
                    <Icon size={14} />
                    {label}
                  </button>
                ))}
              </div>
              {user ? (
                <Link
                  to="/create"
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2.5 rounded-lg transition-colors"
                >
                  <Plus size={16} />
                  Post
                </Link>
              ) : (
                <button
                  onClick={() => setShowAuth(true)}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2.5 rounded-lg transition-colors"
                >
                  <Plus size={16} />
                  Post
                </button>
              )}
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="text-blue-400 animate-spin" size={32} />
              </div>
            ) : posts.length === 0 ? (
              <div className="text-center py-20">
                <Filter size={40} className="text-gray-700 mx-auto mb-4" />
                <p className="text-gray-400 text-lg font-medium">No posts yet</p>
                <p className="text-gray-600 text-sm mt-1">Be the first to start a discussion!</p>
                {user && (
                  <Link to="/create" className="inline-flex items-center gap-2 mt-6 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-6 py-2.5 rounded-lg transition-colors">
                    <Plus size={16} />
                    Create First Post
                  </Link>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {posts.map(post => (
                  <PostCard key={post.id} post={post} onVote={fetchPosts} />
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} defaultMode="signup" />}
    </div>
  );
}
