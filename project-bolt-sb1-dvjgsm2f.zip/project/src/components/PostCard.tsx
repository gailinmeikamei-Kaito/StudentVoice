import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUp, ArrowDown, MessageSquare, Bookmark, Share2, Eye, Lightbulb, Smile, BarChart2, User } from 'lucide-react';
import { Post, supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from '../lib/utils';

type Props = {
  post: Post;
  onVote?: () => void;
};

const typeIcons = {
  innovation: { icon: Lightbulb, label: 'Innovation', color: 'text-teal-400 bg-teal-400/10' },
  meme: { icon: Smile, label: 'Meme', color: 'text-pink-400 bg-pink-400/10' },
  poll: { icon: BarChart2, label: 'Poll', color: 'text-yellow-400 bg-yellow-400/10' },
  text: { icon: MessageSquare, label: 'Discussion', color: 'text-blue-400 bg-blue-400/10' },
  image: { icon: Eye, label: 'Image', color: 'text-green-400 bg-green-400/10' },
};

export default function PostCard({ post, onVote }: Props) {
  const { user } = useAuth();
  const [votes, setVotes] = useState({ up: post.upvotes, down: post.downvotes });
  const [userVote, setUserVote] = useState<'up' | 'down' | null>(null);
  const typeInfo = typeIcons[post.post_type] || typeIcons.text;
  const TypeIcon = typeInfo.icon;

  const handleVote = async (type: 'up' | 'down') => {
    if (!user) return;
    if (userVote === type) {
      await supabase.from('votes').delete().eq('post_id', post.id).eq('user_id', user.id);
      const delta = type === 'up' ? -1 : 0;
      setVotes(v => ({ ...v, up: type === 'up' ? v.up - 1 : v.up, down: type === 'down' ? v.down - 1 : v.down }));
      setUserVote(null);
      void delta;
    } else {
      if (userVote) {
        await supabase.from('votes').update({ vote_type: type }).eq('post_id', post.id).eq('user_id', user.id);
        setVotes(v => ({
          up: type === 'up' ? v.up + 1 : v.up - 1,
          down: type === 'down' ? v.down + 1 : v.down - 1,
        }));
      } else {
        await supabase.from('votes').insert({ post_id: post.id, user_id: user.id, vote_type: type });
        setVotes(v => ({ ...v, up: type === 'up' ? v.up + 1 : v.up, down: type === 'down' ? v.down + 1 : v.down }));
      }
      setUserVote(type);
    }
    onVote?.();
  };

  const author = post.is_anonymous ? null : post.profiles;
  const category = post.categories;

  return (
    <div className="bg-gray-900/50 border border-white/5 rounded-xl p-5 hover:border-white/10 transition-all group">
      <div className="flex items-start gap-4">
        <div className="flex flex-col items-center gap-1 pt-1">
          <button
            onClick={() => handleVote('up')}
            className={`p-1.5 rounded-lg transition-colors ${userVote === 'up' ? 'text-blue-400 bg-blue-400/10' : 'text-gray-500 hover:text-blue-400 hover:bg-blue-400/10'}`}
          >
            <ArrowUp size={18} />
          </button>
          <span className={`text-sm font-bold ${votes.up - votes.down > 0 ? 'text-blue-400' : votes.up - votes.down < 0 ? 'text-red-400' : 'text-gray-400'}`}>
            {votes.up - votes.down}
          </span>
          <button
            onClick={() => handleVote('down')}
            className={`p-1.5 rounded-lg transition-colors ${userVote === 'down' ? 'text-red-400 bg-red-400/10' : 'text-gray-500 hover:text-red-400 hover:bg-red-400/10'}`}
          >
            <ArrowDown size={18} />
          </button>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${typeInfo.color}`}>
              <TypeIcon size={11} />
              {typeInfo.label}
            </span>
            {category && (
              <span className="text-xs text-gray-500 bg-white/5 px-2 py-0.5 rounded-full">
                {category.name}
              </span>
            )}
            {post.is_pinned && (
              <span className="text-xs text-yellow-400 bg-yellow-400/10 px-2 py-0.5 rounded-full">Pinned</span>
            )}
          </div>

          <Link to={`/post/${post.id}`}>
            <h3 className="text-white font-semibold text-base leading-snug mb-2 hover:text-blue-300 transition-colors line-clamp-2">
              {post.title}
            </h3>
          </Link>

          {post.content && (
            <p className="text-gray-400 text-sm leading-relaxed line-clamp-2 mb-3">{post.content}</p>
          )}

          {post.media_url && post.media_type === 'video' ? (
            <video
              src={post.media_url}
              controls
              preload="metadata"
              className="w-full max-h-64 object-cover rounded-lg mb-3 border border-white/5"
            >
              Your browser does not support the video tag.
            </video>
          ) : post.media_url && post.media_type === 'image' ? (
            <img
              src={post.media_url}
              alt={post.title}
              className="w-full max-h-64 object-cover rounded-lg mb-3 border border-white/5"
            />
          ) : post.image_url && (
            <img
              src={post.image_url}
              alt={post.title}
              className="w-full max-h-64 object-cover rounded-lg mb-3 border border-white/5"
            />
          )}

          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {post.tags.slice(0, 4).map(tag => (
                <span key={tag} className="text-xs text-blue-400 bg-blue-400/10 px-2 py-0.5 rounded-full">
                  #{tag}
                </span>
              ))}
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                {author ? (
                  <Link to={`/profile/${author.username}`} className="flex items-center gap-1 hover:text-gray-300 transition-colors">
                    <div className="w-4 h-4 rounded-full bg-blue-500/30 flex items-center justify-center">
                      <User size={9} className="text-blue-400" />
                    </div>
                    <span>{author.username}</span>
                    {author.is_verified && <span className="text-blue-400">✓</span>}
                  </Link>
                ) : (
                  <span className="flex items-center gap-1">
                    <div className="w-4 h-4 rounded-full bg-gray-600 flex items-center justify-center">
                      <User size={9} className="text-gray-400" />
                    </div>
                    Anonymous
                  </span>
                )}
              </div>
              <span>·</span>
              <span>{formatDistanceToNow(post.created_at)}</span>
              <span>·</span>
              <span className="flex items-center gap-1"><Eye size={11} />{post.view_count}</span>
            </div>

            <div className="flex items-center gap-3 text-gray-500">
              <Link to={`/post/${post.id}`} className="flex items-center gap-1 text-xs hover:text-gray-300 transition-colors">
                <MessageSquare size={14} />
                {post.comment_count}
              </Link>
              <button className="hover:text-gray-300 transition-colors"><Share2 size={14} /></button>
              <button className="hover:text-yellow-400 transition-colors"><Bookmark size={14} /></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
