import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Mic2, Bell, Plus, User, Menu, X, LogOut, Shield, ChevronDown, Settings } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import AuthModal from './AuthModal';

export default function Navbar() {
  const { user, profile, signOut } = useAuth();
  const location = useLocation();
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const navLinks = [
    { label: 'Feed', path: '/feed' },
    { label: 'Innovations', path: '/innovations' },
    { label: 'Memes', path: '/memes' },
    { label: 'Transparency', path: '/transparency' },
  ];

  const openLogin = () => { setAuthMode('login'); setShowAuth(true); };
  const openSignup = () => { setAuthMode('signup'); setShowAuth(true); };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-40 bg-gray-950/90 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                <Mic2 size={18} className="text-white" />
              </div>
              <span className="text-white font-bold text-lg tracking-tight">StudentVoice</span>
            </Link>

            <div className="hidden md:flex items-center gap-1">
              {navLinks.map(link => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            <div className="flex items-center gap-3">
              {user ? (
                <>
                  <Link
                    to="/create"
                    className="hidden sm:flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
                  >
                    <Plus size={16} />
                    Post
                  </Link>
                  <Link to="/notifications" className="relative p-2 text-gray-400 hover:text-white transition-colors">
                    <Bell size={20} />
                  </Link>
                  <div className="relative">
                    <button
                      onClick={() => setProfileOpen(!profileOpen)}
                      className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg px-3 py-2 transition-colors"
                    >
                      <div className="w-6 h-6 rounded-full bg-blue-500/30 flex items-center justify-center">
                        <User size={14} className="text-blue-400" />
                      </div>
                      <span className="text-white text-sm font-medium hidden sm:block">
                        {profile?.username || 'User'}
                      </span>
                      <ChevronDown size={14} className="text-gray-400" />
                    </button>
                    {profileOpen && (
                      <div className="absolute right-0 top-full mt-2 w-48 bg-gray-900 border border-white/10 rounded-xl shadow-xl py-1 z-50">
                        <Link
                          to={`/profile/${profile?.username}`}
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
                        >
                          <User size={15} />
                          My Profile
                        </Link>
                        <Link
                          to="/settings"
                          onClick={() => setProfileOpen(false)}
                          className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
                        >
                          <Settings size={15} />
                          Settings
                        </Link>
                        {profile?.is_admin && (
                          <Link
                            to="/admin"
                            onClick={() => setProfileOpen(false)}
                            className="flex items-center gap-3 px-4 py-2.5 text-sm text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 transition-colors"
                          >
                            <Shield size={15} />
                            Admin Panel
                          </Link>
                        )}
                        <hr className="border-white/10 my-1" />
                        <button
                          onClick={() => { signOut(); setProfileOpen(false); }}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                        >
                          <LogOut size={15} />
                          Sign Out
                        </button>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <button onClick={openLogin} className="text-gray-300 hover:text-white text-sm font-medium px-4 py-2 transition-colors">
                    Sign In
                  </button>
                  <button onClick={openSignup} className="bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
                    Join Now
                  </button>
                </div>
              )}
              <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 text-gray-400 hover:text-white transition-colors">
                {menuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden border-t border-white/5 bg-gray-950/95 px-4 py-4 space-y-1">
            {navLinks.map(link => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMenuOpen(false)}
                className={`block px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === link.path ? 'bg-blue-500/20 text-blue-400' : 'text-gray-400 hover:text-white'
                }`}
              >
                {link.label}
              </Link>
            ))}
            {user && (
              <Link
                to="/create"
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2 bg-blue-600 text-white text-sm font-medium px-4 py-2.5 rounded-lg mt-2"
              >
                <Plus size={16} />
                Create Post
              </Link>
            )}
          </div>
        )}
      </nav>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} defaultMode={authMode} />}
      {profileOpen && <div className="fixed inset-0 z-30" onClick={() => setProfileOpen(false)} />}
    </>
  );
}
