import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export type CommunityStats = {
  totalMembers: number;
  totalPosts: number;
  totalComments: number;
  totalInnovations: number;
  totalMemes: number;
  totalPolls: number;
  reportsResolved: number;
  recentlyActive: number;
};

export function useStats() {
  const [stats, setStats] = useState<CommunityStats>({
    totalMembers: 0,
    totalPosts: 0,
    totalComments: 0,
    totalInnovations: 0,
    totalMemes: 0,
    totalPolls: 0,
    reportsResolved: 0,
    recentlyActive: 0,
  });
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    const [
      { count: members },
      { count: posts },
      { count: comments },
      { count: innovations },
      { count: memes },
      { count: polls },
      { count: resolved },
      { count: active },
    ] = await Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('posts').select('*', { count: 'exact', head: true }).eq('is_removed', false),
      supabase.from('comments').select('*', { count: 'exact', head: true }).eq('is_removed', false),
      supabase.from('posts').select('*', { count: 'exact', head: true }).eq('post_type', 'innovation').eq('is_removed', false),
      supabase.from('posts').select('*', { count: 'exact', head: true }).eq('post_type', 'meme').eq('is_removed', false),
      supabase.from('posts').select('*', { count: 'exact', head: true }).eq('post_type', 'poll').eq('is_removed', false),
      supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'resolved'),
      supabase.from('profiles').select('*', { count: 'exact', head: true })
        .gte('last_seen', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()),
    ]);

    setStats({
      totalMembers: members ?? 0,
      totalPosts: posts ?? 0,
      totalComments: comments ?? 0,
      totalInnovations: innovations ?? 0,
      totalMemes: memes ?? 0,
      totalPolls: polls ?? 0,
      reportsResolved: resolved ?? 0,
      recentlyActive: active ?? 0,
    });
    setLoading(false);
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  return { stats, loading, refetch: fetchStats };
}
