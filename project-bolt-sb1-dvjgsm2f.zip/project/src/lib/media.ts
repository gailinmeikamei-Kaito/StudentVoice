import { supabase } from './supabase';

const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_VIDEO_SIZE = 50 * 1024 * 1024; // 50MB
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];

export type MediaUploadResult = {
  url: string;
  type: 'image' | 'video';
};

export function validateFile(file: File): { valid: boolean; error?: string; type?: 'image' | 'video' } {
  if (ALLOWED_IMAGE_TYPES.includes(file.type)) {
    if (file.size > MAX_IMAGE_SIZE) return { valid: false, error: `Image must be under ${MAX_IMAGE_SIZE / 1024 / 1024}MB` };
    return { valid: true, type: 'image' };
  }
  if (ALLOWED_VIDEO_TYPES.includes(file.type)) {
    if (file.size > MAX_VIDEO_SIZE) return { valid: false, error: `Video must be under ${MAX_VIDEO_SIZE / 1024 / 1024}MB` };
    return { valid: true, type: 'video' };
  }
  return { valid: false, error: 'Unsupported file type. Use JPG, PNG, GIF, WebP, MP4, WebM, or MOV.' };
}

export async function uploadMedia(file: File, userId: string): Promise<MediaUploadResult> {
  const validation = validateFile(file);
  if (!validation.valid || !validation.type) throw new Error(validation.error);

  const ext = file.name.split('.').pop() || 'bin';
  const timestamp = Date.now();
  const randomSuffix = Math.random().toString(36).substring(2, 8);
  const path = `${userId}/${timestamp}-${randomSuffix}.${ext}`;

  const { error } = await supabase.storage
    .from('post-media')
    .upload(path, file, { cacheControl: '3600', upsert: false });

  if (error) throw new Error(error.message);

  const { data: urlData } = supabase.storage.from('post-media').getPublicUrl(path);
  return { url: urlData.publicUrl, type: validation.type };
}

export async function deleteMedia(path: string): Promise<void> {
  await supabase.storage.from('post-media').remove([path]);
}
