import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string;
  bio: string;
  is_admin: boolean;
  is_verified: boolean;
  reputation_points: number;
  anonymous_mode: boolean;
  created_at: string;
  updated_at: string;
  last_seen: string;
};

export type Category = {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  post_count: number;
  created_at: string;
};

export type Post = {
  id: string;
  author_id: string;
  title: string;
  content: string;
  post_type: 'text' | 'image' | 'meme' | 'poll' | 'innovation';
  image_url: string;
  media_url: string;
  media_type: '' | 'image' | 'video';
  category_id: string | null;
  is_anonymous: boolean;
  is_pinned: boolean;
  is_removed: boolean;
  upvotes: number;
  downvotes: number;
  comment_count: number;
  view_count: number;
  tags: string[];
  created_at: string;
  updated_at: string;
  profiles?: Profile;
  categories?: Category;
};

export type Comment = {
  id: string;
  post_id: string;
  author_id: string;
  content: string;
  parent_id: string | null;
  is_anonymous: boolean;
  is_removed: boolean;
  upvotes: number;
  downvotes: number;
  created_at: string;
  profiles?: Profile;
};
